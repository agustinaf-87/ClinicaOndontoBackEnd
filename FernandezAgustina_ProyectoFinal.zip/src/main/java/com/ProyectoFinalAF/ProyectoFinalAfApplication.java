package com.ProyectoFinalAF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalAfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalAfApplication.class, args);
	}

}
